package com.collaboration.base;

import java.io.Serializable;

public interface Identifiable {
    Serializable getId();
}
