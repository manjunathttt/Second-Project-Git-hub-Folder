package com.collaboration.base;

public interface ValueObject {
}
