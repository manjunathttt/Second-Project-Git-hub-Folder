package com.collaboration.base;


public interface Entity extends Identifiable {
}
