package com.collaboration.model;

import javax.persistence.*;

import com.collaboration.base.AbstractEntity;




@Entity
@Table(name = "blog_comment")
public class BlogComment extends AbstractEntity
{
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "blog_post_id")
    protected BlogPost blogPost;

    @Lob
    @Column(name = "body")
    protected String body;

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public BlogPost getBlogPost() {
        return blogPost;
    }

    public void setBlogPost(BlogPost blogPost) {
        this.blogPost = blogPost;
    }
}
