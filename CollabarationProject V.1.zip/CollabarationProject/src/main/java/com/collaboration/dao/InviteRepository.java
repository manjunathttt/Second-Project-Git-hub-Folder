package com.collaboration.dao;

import org.springframework.stereotype.Repository;

import com.collaboration.base.AbstractRepository;
import com.collaboration.model.Invite;

@Repository
public class InviteRepository extends AbstractRepository<Invite>
{

}
