package com.collaboration.dao;

import org.springframework.stereotype.Repository;

import com.collaboration.base.AbstractRepository;
import com.collaboration.model.UserProfile;

@Repository
public class UserProfileRepository extends AbstractRepository<UserProfile>
{
	public UserProfile getByUsername(String username) {
        return getFirstBy("user.username", username);
    }

    public UserProfile getByChatSessionId(String sessionId) {
        return getFirstBy("chatStatus.sessionId", sessionId);
    }
}
