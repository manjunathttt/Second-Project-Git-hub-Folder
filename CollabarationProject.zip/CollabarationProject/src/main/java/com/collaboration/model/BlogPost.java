package com.collaboration.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

import com.collaboration.base.AbstractEntity;


@Entity
@Table(name = "blog_post")
public class BlogPost extends AbstractEntity
{
	@Column(name = "title", length = 1000)
    protected String title;

    @Column(name = "body")
    @Lob
    protected String body;

    @OneToMany(mappedBy = "blogPost", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    protected List<BlogComment> comments = new ArrayList<>();

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public List<BlogComment> getComments() {
        return comments;
    }

    public void setComments(List<BlogComment> comments) {
        this.comments = comments;
    }

    public void addComment(BlogComment blogComment) {
        comments.add(blogComment);
    }
}
