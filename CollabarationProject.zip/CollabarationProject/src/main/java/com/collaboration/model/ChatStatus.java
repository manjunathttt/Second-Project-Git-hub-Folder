package com.collaboration.model;

import javax.persistence.*;

import com.collaboration.base.GeneratedIdValueObject;

@Entity
@Table(name = "chat_status")
public class ChatStatus extends GeneratedIdValueObject
{
	@Column(name = "online")
    protected Boolean online;

    @Column(name = "session_id")
    protected String sessionId;

    @OneToOne
    @JoinColumn(name="user_profile_id")
    protected UserProfile userProfile;

    protected ChatStatus() {
    }

    protected ChatStatus(Boolean online, String sessionId, UserProfile userProfile) {
        this.online = online;
        this.sessionId = sessionId;
        this.userProfile = userProfile;
    }

    public Boolean getOnline() {
        return online;
    }

    public void setOnline(Boolean online) {
        this.online = online;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }
}
